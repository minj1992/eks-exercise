package com.example.configsecretapp.config_secret_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigSecretAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigSecretAppApplication.class, args);
	}

}
